package api;

/**
 * A listener for dialog events.
 */
public interface ShowDialogListener {
	public void showDialog(String dialog);
}
