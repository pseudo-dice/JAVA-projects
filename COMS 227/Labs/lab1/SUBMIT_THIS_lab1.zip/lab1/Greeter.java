package lab1;

public class greeter {

	public static void main(String[] args) {
		System.out.println("Hello, Abhaya");

	}

}
